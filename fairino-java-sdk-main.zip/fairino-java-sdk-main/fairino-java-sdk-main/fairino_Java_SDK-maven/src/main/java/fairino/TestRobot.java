package fairino;

public class TestRobot {
        public static void main(String[] args) {
            Robot robot = new Robot();

            // Inicialización básica
            robot.LoggerInit(FrLogType.DIRECT, FrLogLevel.INFO, "C:/Users/pardo/Desktop/fairino-java-sdk-main/fairino_Java_SDK-maven/log", 10, 10);

            if (robot.RPC("192.168.237.128") != 0) {
                System.out.println("Error: No se pudo conectar con el controlador");
                return;
            }

            // Preparación de seguridad
            robot.ResetAllError();
            robot.RobotEnable(1);
            robot.MotionQueueClear();
            robot.Sleep(1000);

            int rtn = -1;
            JointPos j1 = new JointPos(0, -90, 0, -90, 0, 0);
            JointPos j2 = new JointPos(10, -80, 10, -100, 0, 0);
            JointPos j3 = new JointPos(20, -70, 20, -110, 0, 0);

            DescPose p1 = new DescPose(300, 100, 400, 180, 0, 180);
            DescPose p2 = new DescPose(300, -100, 400, 180, 0, 180);
            DescPose p3 = new DescPose(400, 0, 300, 180, 0, 180);

            ExaxisPos epos = new ExaxisPos(0, 0, 0, 0);
            DescPose offset = new DescPose(0, 0, 0, 0, 0, 0);
            int tool = 0;
            int user = 0;
            double vel = 20.0;
            double acc = 50.0;
            double ovl = 100.0;

            rtn = robot.MoveJ(j1, p1, tool, user, vel, acc, ovl, epos, -1.0, 0, offset);
            System.out.printf("MoveJ PTP: %d\n", rtn);

            rtn = robot.MoveL(p2, tool, user, vel, acc, ovl, -1.0, 0, epos, 0, 0, offset, -1, 0, 0, 10);
            System.out.printf("MoveL Lineal: %d\n", rtn);

            // Se requiere un punto intermedio (p2) y un destino (p3)
            rtn = robot.MoveC(p2, tool, user, vel, acc, epos, 0, offset, p3, tool, user, vel, acc, epos, 0, offset, ovl, -1.0, -1, 0);
            System.out.printf("MoveC Circular: %d\n", rtn);

            rtn = robot.MoveCart(p1, tool, user, vel, acc, ovl, -1.0, -1);
            System.out.printf("MoveCart: %d\n", rtn);
        }
}
